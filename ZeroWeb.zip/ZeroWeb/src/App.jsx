import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import Footer from './components/Footer';
import ContentSection from './components/ContentSection';
import FeSection from './components/ FeSection';
import FeSectionFlipped from './components/FeSectionFlipped';
import FefSection from './components/FefSection';
import Bento from './components/Bento';

function App() {
  return (
    <div>
      <Header />
      <main>
        <Hero />
        <ContentSection />
        {/* <Features /> */}
        <FeSection/>
       < FeSectionFlipped/>
       <FefSection />
       <Bento/>
      </main>
      <Footer />
    </div>
  );
}

export default App;
