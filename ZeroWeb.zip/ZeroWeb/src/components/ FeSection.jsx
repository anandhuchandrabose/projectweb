import React from "react";

const FeSection = () => {
  return (
    <section className="bg-white h-[60vh] flex items-center justify-center">
      <div className="container mx-auto px-6 flex flex-col lg:flex-row items-center justify-between">
        {/* Left Side Content */}
        <div className="w-full lg:w-1/2 flex justify-center text-left">
          <div>
            <span className="inline-block text-accent font-semibold text-sm uppercase mb-4">
              What is fresmo?
            </span>
            <h1 className="text-3xl font-extrabold text-gray-900 leading-tight mb-4 lg:text-5xl">
              Your Guide to Ordering from Local <br />
              <span>Home Chefs Made Easy</span>
            </h1>
            <p className="text-gray-600 text-lg mb-6">
              Fresno connects you with talented home chefs, making meal delivery
              effortless.
            </p>
            <button className="bg-accent hover:bg-accent text-white font-semibold px-6 py-3 rounded-full text-lg">
              Get started &rarr;
            </button>
          </div>
        </div>

        {/* Right Side Image */}
        <div className="w-full lg:w-1/2 flex justify-center">
          <img
            src="https://via.placeholder.com/400x300"
            alt="Delicious Home-Cooked Meal"
            className="rounded-lg shadow-lg"
          />
        </div>
      </div>
    </section>
  );
};

export default FeSection;
