import React from 'react';
import PlaceholderImage from '../assets/placeholder.png';

const Hero = () => {
  return (
    <section className="pt-40 h-[100vh] pb-20 bg-white">
      <div className="container mx-auto px-16 flex items-center justify-center flex-col md:flex-row">
        {/* Text Section */}
        <div className="w-full md:w-1/2 text-center md:text-left">
          <h1 className="text-[60px] font-semibold mb-4 tracking-tight leading-[4.5rem]">
          Discover Fresno's <br />  Home-Cooked Delivery Service
          </h1>
          <p className="text-lg font-thin mb-8 text-gray-500 tracking-normal">
          Deno is the open-source JavaScript <br /> runtime for the modern web.
          </p>
          <button className="bg-accent text-white px-6 py-3 rounded-full hover:bg-blue-600 font-semibold">
            Get Started
          </button>
        </div>
        {/* Image Section */}
        <div className="w-full md:w-1/2 mt-8 md:mt-0 ">
          <img
            src={PlaceholderImage}
            alt="Hero"
            className="w-full h-auto"
          />
        </div>
      </div>
    </section>
  );
};

export default Hero;
