import React from 'react';
import PlaceholderImage from '../assets/placeholder.png';

const Features = () => {
  const features = [
    {
      title: 'Secure by Default',
      description: 'Experience a secure environment out of the box.',
      image: PlaceholderImage,
    },
    {
      title: 'TypeScript Support',
      description: 'First-class support for TypeScript.',
      image: PlaceholderImage,
    },
    {
      title: 'Modern Tooling',
      description: 'Use the latest features and tools.',
      image: PlaceholderImage,
    },
  ];

  return (
    <section id="features" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-semibold text-center mb-12">Features</h2>
        <div className="flex flex-wrap -mx-4">
          {features.map((feature, index) => (
            <div key={index} className="w-full md:w-1/3 px-4 mb-8">
              <div className="bg-gray-100 rounded-lg shadow p-6 text-center">
                <img src={feature.image} alt={feature.title} className="mx-auto mb-4 w-24 h-24" />
                <h3 className="text-2xl font-semibold mb-4">{feature.title}</h3>
                <p className="text-gray-600 font-normal">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
