import React from "react";

const ContentSection = () => {
  return (
    <section className="text-gray-600 h-[80vh] body-font">
      <div className="container px-5 mx-auto">
        <div className="flex flex-wrap w-full mb-20">
          <div className="lg:w-1/2 w-full mb-6 lg:mb-0">
            <h1 className="sm:text-3xl text-2xl font-medium title-font mb-2 text-gray-900">
              Discover the Unique Features of Fresno's Home-Cooked Meal
              Delivery Service
            </h1>
            <div className="h-1 w-20 bg-accent rounded"></div>
          </div>
          <p className="lg:w-1/2 w-full leading-relaxed text-gray-500">
            Fresno connects you with talented local chefs who prepare delicious
            home-cooked meals just for you. Enjoy the taste of fresh ingredients
            sourced from local markets, ensuring every bite is flavorful and
            wholesome. With our quick delivery service, your meal arrives hot
            and ready to enjoy.
          </p>
        </div>
        <div className="flex flex-wrap -m-4 ">
          {[
            {
              id: 1,
              imgSrc: "https://dummyimage.com/720x400",
              title:
                "Savor Home-Cooked Meals Crafted by Local Chefs in Your Community",
              description:
                "Experience the joy of eating meals made with love and care.",
            },
            {
              id: 2,
              imgSrc: "https://dummyimage.com/721x401",
              title:
                "Enjoy Fresh Ingredients for Every Meal Delivered Right to Your Door",
              description:
                "Our chefs prioritize quality by using only the freshest, locally sourced ingredients.",
            },
            {
              id: 3,
              imgSrc: "https://dummyimage.com/722x402",
              title:
                "Experience Quick Delivery for Your Favorite Home-Cooked Meals Anytime",
              description:
                "Get your meals delivered swiftly, so you can enjoy them without delay.",
            },
          ].map((item) => (
            <div key={item.id} className="xl:w-1/3 md:w-1/2 p-4 pt-16">
              <div className="bg-white shadow-md border-gray-800 p-6 rounded-lg">
                <img
                  className="h-40 rounded w-full object-cover object-center mb-6"
                  src={item.imgSrc}
                  alt={item.title}
                />
                <h3 className="tracking-widest text-accent text-xs font-medium title-font">
                  {/* Subtitle can be added here if needed */}
                </h3>
                <h2 className="text-lg text-gray-900 font-medium title-font mb-4">
                  {item.title}
                </h2>
                <p className="leading-relaxed text-base">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ContentSection;
